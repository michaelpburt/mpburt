import requests
from bs4 import BeautifulSoup
import pandas as pd
import datetime 
from time import strptime
import MySQLdb as mdb



current_time = datetime.datetime.now()
r = requests.get('https://www.dmr.nd.gov/oilgas/riglist.asp')
r.raise_for_status()

t_ = BeautifulSoup(r.content, 'html.parser').find_all('table')[2].find_all('tr')
r_ = []

for i in t_:
	rn_ = [current_time]
	rn_.extend([j.string for j in i.find_all('td')])
	try:
		rn_[8] = datetime.datetime(*strptime(rn_[8], "%m/%d/%Y")[:6])
	except Exception:
		rn_[8] = ''
		pass 
	r_.append(rn_)

headers = (['datetime', 'rig_name', 'operator', 
			'well_name', 'current_location', 
			'county', 'fileno', 'api', 
			'startdate', 'next_location'])

df = pd.DataFrame(r_, columns=headers)
df = df.set_index(['datetime', 'rig_name'])

conn = DatabaseService('root', '774742310', 'localhost', 'oag').con

df.to_sql(name='nd_rig_report'
	,con=conn
	,if_exists='append'
	,flavor='mysql'
	,schema='oag')

