# Dependencies
from sqlalchemy import Table
from sqlalchemy import MetaData
from sqlalchemy import create_engine

# Define model
def model(conn_str):
	engine 					= create_engine(conn_str)
	metadata 				= MetaData()
	metadata.bind 			= engine
	nd_rig_report 			= Table('nd_rig_report', 
									metadata, 
									autoload=True, 
									autoload_with=engine)
	return {'engine':engine,
			'nd_rig_report':nd_rig_report}

def writemodel(target, payload, engine=engine):
	with engine.execute(target.insert(), payload) as result:
		load_count 			= result.rowcount
		reject_count 		= len(payload) - load_count
		return {'load_count':load_count,
						'reject_count':reject_count}