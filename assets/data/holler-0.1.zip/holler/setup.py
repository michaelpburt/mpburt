#!/home/ubuntu/oagenv/bin/python

from distutils.core import setup

setup(name='Holler',
      version='0.1',
      description='Python Holler Utilities',
      author='Michae Burt',
      author_email='michaelpburt@gmail.com',
      url='http://mpburt.com/',
      packages=['holler.model', 'holler.collect'],
     )